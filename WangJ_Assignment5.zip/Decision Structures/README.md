## Welcome Mr. G (or user)

Welcome to the standing wave equation for 2 fixed ends variable

## Folder Structure

The workspace contains two folders by default, where:

- `src`: the folder to maintain sources
- `lib`: the folder to maintain the planner and testing file

Meanwhile, the compiled output files will be generated in the `bin` folder by default. For example, classes.

Have a good day!